package com.example.videojocs;

public class Game {
    private String  name;
    private String  players;
    private int     image;

    public Game(String name, String  players, int image) {
        this.name   = name;
        this.players = players;
        this.image = image;
    }

    public String getName() { return name; }

    public String getPlayers() { return players; }

    public int getImage()   { return image; }
}
