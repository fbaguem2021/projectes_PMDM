package com.example.videojocs;

import java.io.Serializable;

public class Game implements Serializable {
    private String  name;
    private String  players;
    private int     image;

    public Game(String name, String  players, int image) {
        this.name   = name;
        this.players = players;
        this.image = image;
    }

    public String getName() { return name; }

    public String getPlayers() { return players; }

    public int getImage()   { return image; }
}
