package com.example.videojocs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class GamesAdapter extends RecyclerView.Adapter<GamesAdapter.ViewHolder> implements View.OnClickListener {
    private ArrayList<Game> games;
    private View.OnClickListener listener;

    public GamesAdapter(ArrayList<Game> games) {
        this.games = games;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView lblName;
        ImageView imgGame;

        public ViewHolder(@NonNull View item) {
            super(item);
            lblName = item.findViewById(R.id.lblName);
            imgGame = item.findViewById(R.id.imgGame);
        }

        void bindGame(Game game) {

            lblName.setText(game.getName());
            imgGame.setImageResource(game.getImage());
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.games_item, parent, false);
        item.setOnClickListener(this);
        return new ViewHolder(item);
    }

    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.bindGame(games.get(position));
    }

    public int getItemCount() {
        return games.size();
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View view) {
        if (listener != null) {
            listener.onClick(view);
        }
    }
}
