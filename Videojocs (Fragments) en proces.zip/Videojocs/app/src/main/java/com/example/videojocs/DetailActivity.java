package com.example.videojocs;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    final static String GAME_EXTRA = "game";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent intent = getIntent();

        Game game = (Game) intent.getSerializableExtra(GAME_EXTRA);

        FragmentManager mgr = getSupportFragmentManager();
        DetailFragment detailFragment = (DetailFragment) mgr.findFragmentById(R.id.frgDetail);
        detailFragment.fillData(game);


    }
}