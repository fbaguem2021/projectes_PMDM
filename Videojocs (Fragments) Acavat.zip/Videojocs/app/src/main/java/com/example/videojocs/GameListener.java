package com.example.videojocs;

public interface GameListener {
    void  onSelectedGame(Game game);
}
