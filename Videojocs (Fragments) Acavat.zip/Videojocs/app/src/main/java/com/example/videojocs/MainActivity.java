package com.example.videojocs;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements GameListener {

    private FragmentManager mgr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final ArrayList<Game> games = getGames();

        mgr = getSupportFragmentManager();
        ListFragment listFragment = (ListFragment) mgr.findFragmentById(R.id.frgList);
        listFragment.setGameListener(this);
        listFragment.addListData(games);
    }

    @Override
    public void onSelectedGame(Game game) {
        DetailFragment detailFragment = (DetailFragment) mgr.findFragmentById(R.id.frgDetail);

        // L'aplicació s'està executant en telefon
        if (detailFragment == null) {
            Intent intent = new Intent(this, DetailActivity.class);
            intent.putExtra(DetailActivity.GAME_EXTRA, game);
            startActivity(intent);
            // L'aplicacióp s'està executant en tableta
        } else {
            detailFragment.fillData(game);
        }


    }

    private ArrayList<Game> getGames() {
        ArrayList<Game> games = new ArrayList<>();

        games.add(new Game("Final Fantasy 1", "2.490.000", R.drawable.final_fantasy1));
        games.add(new Game("Final Fantasy 2", "1.730.000", R.drawable.final_fantasy2));
        games.add(new Game("Final Fantasy 3", "3.801.000", R.drawable.final_fantasy3));
        games.add(new Game("Final Fantasy 4", "4.453.112", R.drawable.final_fantasy4));
        games.add(new Game("Final Fantasy 5", "3.072.000", R.drawable.final_fantasy5));
        games.add(new Game("Final Fantasy 6", "4.002.000", R.drawable.final_fantasy6));
        games.add(new Game("Final Fantasy 7", "16.080.000", R.drawable.final_fantasy7));
        games.add(new Game("Final Fantasy 8", "8.864 000", R.drawable.final_fantasy8));
        games.add(new Game("Final Fantasy 9", "5.761.000", R.drawable.final_fantasy9));
        games.add(new Game("Final Fantasy 10", "8.005.113", R.drawable.final_fantasy10));

        return games;
    }
}