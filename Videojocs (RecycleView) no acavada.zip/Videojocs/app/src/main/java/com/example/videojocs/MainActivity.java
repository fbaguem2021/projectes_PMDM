package com.example.videojocs;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Game[] games = getGames();

        final RecyclerView listGames = findViewById(R.id.listGames);
        GamesAdapter adapter = new GamesAdapter(games);

        listGames.setHasFixedSize(true);
        listGames.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        listGames.setAdapter(adapter);

        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView nameSelected = findViewById(R.id.nameSelected);
                TextView playersSelected = findViewById(R.id.playersSelected);
                ImageView imgSelected = findViewById(R.id.imgSelected);

                Game game = games[listGames.getChildAdapterPosition(view)];

                nameSelected.setText(game.getName());
                playersSelected.setText(game.getPlayers());
                imgSelected.setImageResource(game.getImage());
            }
        });
        /*
        listGames.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                Game game = games[i];

                TextView nameSelected = findViewById(R.id.nameSelected);
                TextView playersSelected = findViewById(R.id.playersSelected);
                ImageView imgSelected = findViewById(R.id.imgSelected);

                nameSelected.setText(game.getName());
                playersSelected.setText(game.getPlayers());
                imgSelected.setImageResource(game.getImage());
            }
        });
        */
    }

    private Game[] getGames() {
        return new Game[]{
                new Game("Final Fantasy 1", "2.490.000", R.drawable.final_fantasy1),
                new Game("Final Fantasy 2", "1.730.000", R.drawable.final_fantasy2),
                new Game("Final Fantasy 3", "3.801.000", R.drawable.final_fantasy3),
                new Game("Final Fantasy 4", "4.453.112", R.drawable.final_fantasy4),
                new Game("Final Fantasy 5", "3.072.000", R.drawable.final_fantasy5),
                new Game("Final Fantasy 6", "4.002.000", R.drawable.final_fantasy6),
                new Game("Final Fantasy 7", "16.080.000", R.drawable.final_fantasy7),
                new Game("Final Fantasy 8", "8.864 000", R.drawable.final_fantasy8),
                new Game("Final Fantasy 9", "5.761.000", R.drawable.final_fantasy9),
                new Game("Final Fantasy 10", "8.005.113", R.drawable.final_fantasy10)
        };
    }
}