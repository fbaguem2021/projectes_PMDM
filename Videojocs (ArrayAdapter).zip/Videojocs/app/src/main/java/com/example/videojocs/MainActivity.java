package com.example.videojocs;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Game[] games = getGames();

        ListView listGames = findViewById(R.id.listGames);
        GamesAdapter adapter =new GamesAdapter(this, games);
        listGames.setAdapter(adapter);

        listGames.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                Game game = games[i];
                TextView nameSelected = findViewById(R.id.nameSelected);
                nameSelected.setText(game.getName());
                TextView playersSelected = findViewById(R.id.playersSelected);
                playersSelected.setText(game.getPlayers());
                ImageView imgSelected = findViewById(R.id.imgSelected);
                imgSelected.setImageResource(game.getImage());
            }
        });
    }

    private Game[] getGames()
    {
        Game[] games = {
                new Game("Final Fantasy 1",     "2.490.000",     R.drawable.final_fantasy1),
                new Game("Final Fantasy 2",     "1.730.000",     R.drawable.final_fantasy2),
                new Game("Final Fantasy 3",     "3.801.000",     R.drawable.final_fantasy3),
                new Game("Final Fantasy 4",     "4.453.112",     R.drawable.final_fantasy4),
                new Game("Final Fantasy 5",     "3.072.000",     R.drawable.final_fantasy5),
                new Game("Final Fantasy 6",     "4.002.000",     R.drawable.final_fantasy6),
                new Game("Final Fantasy 7",     "16.080.000",    R.drawable.final_fantasy7),
                new Game("Final Fantasy 8",     "8.864 000",     R.drawable.final_fantasy8),
                new Game("Final Fantasy 9",     "5.761.000",     R.drawable.final_fantasy9),
                new Game("Final Fantasy 10",    "8.005.113",     R.drawable.final_fantasy10)
        };
        return games;
    }
}