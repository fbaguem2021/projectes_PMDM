package com.example.videojocs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class GamesAdapter extends ArrayAdapter
{
    private Game [] games;

    public GamesAdapter(Context context, Game[] games)
    {
        super(context, R.layout.game_layout, games);
        this.games = games;
    }

    @Override
    public View getView(int position, View currentview, ViewGroup parent)
    {
        View item = LayoutInflater.from(getContext()).
                inflate(R.layout.game_layout, parent, false);

        TextView lblName = item.findViewById(R.id.lblName);
        ImageView imgGame = item.findViewById(R.id.imgGame);

        lblName.setText(games[position].getName());
        imgGame.setImageResource(games[position].getImage());

        return item;
    }
}
